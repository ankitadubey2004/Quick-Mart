# Amazon-clone
 Its a amzon clone website
